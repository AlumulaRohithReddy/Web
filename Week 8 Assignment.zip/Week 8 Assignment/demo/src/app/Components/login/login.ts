import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterOutlet } from '@angular/router';
import { AuthService } from '../../services/auth';
declare var window: any;
declare var grecaptcha: any;
@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule,RouterOutlet],
  templateUrl: './login.html'
})

export class Login {
errormessage = '';
 form = {
    username: '',
    password: '',
    captcha: ''
  };

  loading = false;
  error = '';


captchaToken: string = '';


  constructor(private authService: AuthService, private router: Router) {}

ngAfterViewInit() {
  setTimeout(() => {
    if (typeof grecaptcha !== 'undefined') {

      grecaptcha.render('captcha', {
        sitekey: '6LeBeHUsAAAAAOG7iNSYiC45naDSjW6Aa2XCDpFj',   // 🔥 replace this
        callback: (token: string) => {
          console.log('Captcha Token:', token);
          this.captchaToken = token;
        }
      });

    } else {
      console.error('grecaptcha not loaded');
    }
  }, 1000);
}
goRegister() {
  this.router.navigate(['/register']);
}
goForgotPassword() {
  this.router.navigate(['/forgot-password']);
}

  login() {

  this.error = '';

  if (!this.captchaToken) {
    alert('Please complete CAPTCHA');
    return;
  }

  if (!this.form.username || !this.form.password) {
    this.error = 'All fields are required';
    return;
  }

  this.loading = true;

  const data = {
    username: this.form.username,
    password: this.form.password,
    captcha: this.captchaToken   
  };
console.log({
  username: this.form.username,
  password: this.form.password,
  captcha: this.captchaToken
});
  this.authService.login(data).subscribe({
    next: (res: any) => {

      this.authService.save(res.token);

      const role = this.authService.getRole();

      if (role === 'Admin') {
        this.router.navigate(['/admin']);
      } else if (role === 'Trainer') {
        this.router.navigate(['/trainer']);
      } else {
        this.router.navigate(['/student']);
      }

      this.loading = false;
    },

    error: (err) => {
  console.log(err.error);
  this.error = err.error;


      // 🔥 Reset captcha on error
     grecaptcha.reset();
      this.captchaToken = '';
    }
  });
}

}