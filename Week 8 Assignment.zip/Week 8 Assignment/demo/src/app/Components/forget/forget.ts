import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-forgot-password',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './forget.html'
})
export class ForgotPasswordComponent {

  username = '';
  error = '';

  constructor(private auth: AuthService, private router: Router) {}

  verifyUser() {
    this.error = '';

    if (!this.username) {
      this.error = 'Username is required';
      return;
    }

    this.auth.verifyUser({ username: this.username }).subscribe({
      next: () => {
        // navigate to reset page
        this.router.navigate(['/reset-password'], {
          queryParams: { username: this.username }
        });
      },
      error: () => {
        this.error = 'User not found';
      }
    });
  }
}