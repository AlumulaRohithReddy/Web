import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { AdminService } from '../../services/admin';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-admin',
  imports: [CommonModule],
  templateUrl: './admin-dashboard.html'
})
export class AdminComponent implements OnInit {
 loading = false;
  users: any[] = [];

  constructor(private adminService: AdminService, private cdr: ChangeDetectorRef) {}

  ngOnInit() {
    this.loadUsers();
  }

  loadUsers() {
    
    this.adminService.getUsers().subscribe((data: any) => {
      this.users = data;
      this.cdr.detectChanges(); // Ensure view updates after data load
      console.log('Users loaded:', this.users);
      this.loading = false;
    });
  }

  confirmDelete(id: number) {
    if (confirm('Are you sure?')) {
      this.adminService.deleteUser(id).subscribe(() => {
        this.loadUsers();
        this.cdr.detectChanges(); // refresh list
      });
    }
  }
}