import {ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { MaterialService, StudyMaterial } from '../../services/materials';

import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-student',
  imports: [FormsModule,CommonModule],
  templateUrl: './student-dashboard.html'
})
export class StudentComponent implements OnInit {

  materials: StudyMaterial[] = [];
  
  loading = false;
  error = '';
activeTab: string = 'dashboard';



  constructor(
    private materialService: MaterialService,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.loadMaterials();

  }
setTab(tab: string) {
  this.activeTab = tab;

  if (tab === 'materials') {
    this.loadMaterials();
    this.cdr.detectChanges(); // Ensure view updates after data load
  }}
  loadMaterials() {
    this.loading = true;

    this.materialService.getMaterials().subscribe({
      next: res => this.materials = res,
      error: () => this.error = 'Failed to load materials',
      complete: () => this.loading = false
    });
  }
  openFile(url: string) {
    window.open(url, '_blank');
  }

  logout() {
    localStorage.removeItem('token');
    this.router.navigate(['/login']);
  }
}