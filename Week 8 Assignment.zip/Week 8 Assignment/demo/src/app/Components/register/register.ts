import { Component } from '@angular/core';
import { AuthService } from '../../services/auth';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-register',
  imports: [FormsModule,CommonModule],
  templateUrl: './register.html'
})
export class RegisterComponent {

  form = {
    name:'',
    username: '',
    password: '',
    role: 'Student'
  };

  showPassword = false;
  loading = false;
  error = '';

  constructor(private auth: AuthService, private router: Router) {}

  togglePassword() {
    this.showPassword = !this.showPassword;
  }

  register() {
    this.error = '';

    // Validation
    if (!this.form.name || !this.form.username || !this.form.password) {
      this.error = 'All fields are required';
      return;
    }

    if (this.form.password.length < 4) {
      this.error = 'Password must be at least 4 characters';
      return;
    }

    this.loading = true;

    this.auth.register(this.form).subscribe({
      next: () => {
        alert('Registration successful');
        this.router.navigate(['/login']);
      },
      error: err => {
        this.error = err.error || 'Registration failed';
        this.loading = false;
      },
      complete: () => this.loading = false
    });
  }
}