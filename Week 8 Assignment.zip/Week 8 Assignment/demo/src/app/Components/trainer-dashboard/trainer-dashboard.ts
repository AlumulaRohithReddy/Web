import { Component, OnInit } from '@angular/core';
import { TrainerService, User } from '../../services/trainer';
import { MaterialService, StudyMaterial } from '../../services/materials';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-trainer',
  imports: [FormsModule,CommonModule],
  templateUrl: './trainer-dashboard.html'
})
export class TrainerComponent implements OnInit {

  activeTab: string = 'dashboard';

  students: User[] = [];
  materials: StudyMaterial[] = [];

  loading = false;

  newMaterial = {
    title: '',
    description: '',
    fileUrl: ''
  };

  selectedStudent: User | null = null;

  constructor(
    private trainerService: TrainerService,
    private materialService: MaterialService,
    private router: Router
  ) {}

  ngOnInit() {
    this.loadDashboard();
  }

  setTab(tab: string) {
    this.activeTab = tab;

    if (tab === 'students') this.loadStudents();
    if (tab === 'materials') this.loadMaterials();
 
  }

  // DASHBOARD
  loadDashboard() {
    this.loadStudents();
    this.loadMaterials();
  }

  // STUDENTS
  loadStudents() {
    this.trainerService.getStudents().subscribe((res:any) => this.students = res);
  }

  editStudent(s: User) {
    this.selectedStudent = { ...s };
  }

  updateStudent() {
    if (!this.selectedStudent) return;

    this.trainerService.updateStudent(this.selectedStudent).subscribe(() => {
      this.loadStudents();
      this.selectedStudent = null;
    });
  }

  deleteStudent(id: number) {
    if (confirm('Delete this student?')) {
      this.trainerService.deleteStudent(id).subscribe(() => {
        this.students = this.students.filter(s => s.id !== id);
      });
    }
  }

  // MATERIALS
  loadMaterials() {
    this.materialService.getMyMaterials().subscribe(res => this.materials = res);
  }

  addMaterial() {
    console.log(this.newMaterial);
    this.materialService.addMaterial(this.newMaterial).subscribe(() => {
      console.log(this.newMaterial);
      this.newMaterial = { title: '', description: '', fileUrl: '' };
      this.loadMaterials();
    });
  }

  deleteMaterial(id: number) {
    this.materialService.deleteMaterial(id).subscribe(() => {
      this.materials = this.materials.filter(m => m.id !== id);
    });
  }

  // FEEDBACK
 

  // LOGOUT
  logout() {
    localStorage.removeItem('token');
    this.router.navigate(['/login']);
  }
}