import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../../services/auth';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-reset-password',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './reset.html'
})
export class ResetPasswordComponent implements OnInit {

  username = '';
  password = '';
  confirmPassword = '';

  error = '';
  success = '';

  constructor(
    private route: ActivatedRoute,
    private auth: AuthService,
    private router: Router
  ) {}

  ngOnInit() {
    this.username = this.route.snapshot.queryParams['username'];
  }

  resetPassword() {
    this.error = '';
    this.success = '';

    if (!this.password || !this.confirmPassword) {
      this.error = 'All fields are required';
      return;
    }

    if (this.password !== this.confirmPassword) {
      this.error = 'Passwords do not match';
      return;
    }

    this.auth.resetPassword({
      username: this.username,
      newPassword: this.password
    }).subscribe({
      next: () => {
        this.success = 'Password updated successfully';

        setTimeout(() => {
          this.router.navigate(['/login']);
        }, 1500);
      },
      error: () => {
        this.error = 'Failed to reset password';
      }
    });
  }
}