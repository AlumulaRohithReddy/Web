import { CanActivateFn, ActivatedRouteSnapshot, Router } from '@angular/router';
import { inject } from '@angular/core';
import { AuthService } from '../services/auth';

export const roleGuard: CanActivateFn = (route: ActivatedRouteSnapshot) => {

  const authService = inject(AuthService);
  const router = inject(Router);

  const expectedRole = route.data['role']; // Admin / Trainer / Student
  const token = authService.getToken();

  if (!token) {
    router.navigate(['/login']);
    return false;
  }

  try {
    const payload = JSON.parse(atob(token.split('.')[1]));

    const userRole = payload['http://schemas.microsoft.com/ws/2008/06/identity/claims/role'];

    // Check role
    if (userRole !== expectedRole) {
      console.log('Access denied: Role mismatch');
      router.navigate(['/login']);
      return false;
    }

  } catch (error) {
    router.navigate(['/login']);
    return false;
  }

  return true;
};