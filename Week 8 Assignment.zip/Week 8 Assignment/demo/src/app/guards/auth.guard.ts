import { CanActivateFn, Router } from '@angular/router';
import { inject } from '@angular/core';
import { AuthService } from '../services/auth';

export const authGuard: CanActivateFn = (route, state) => {

  const authService = inject(AuthService);
  const router = inject(Router);

  const token = authService.getToken();

  // If no token → redirect to login
  if (!token) {
    router.navigate(['/login']);
    return false;
  }
  if (!authService.getToken() || authService.isTokenExpired()) {
    authService.logout();
    router.navigate(['/login']);
    return false;
  }
  // Optional: check token expiry
  try {
    const payload = JSON.parse(atob(token.split('.')[1]));
    const expiry = payload.exp * 1000;

    if (Date.now() > expiry) {
      authService.logout();
      router.navigate(['/login']);
      return false;
    }
  } catch (e) {
    authService.logout();
    router.navigate(['/login']);
    return false;
  }

  return true;
};