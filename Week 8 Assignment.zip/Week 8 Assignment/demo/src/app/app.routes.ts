import { Routes } from '@angular/router';
import { Login } from './Components/login/login';
import { AdminComponent } from './Components/admin-dashboard/admin-dashboard';
import { TrainerComponent } from './Components/trainer-dashboard/trainer-dashboard';
import { StudentComponent } from './Components/student-dashboard/student-dashboard';
import { authGuard } from './guards/auth.guard';
import { roleGuard } from './guards/role.guard';
import { RegisterComponent } from './Components/register/register';
import { ForgotPasswordComponent } from './Components/forget/forget';
import { ResetPasswordComponent } from './Components/reset/reset';
export const routes: Routes = [
{path: 'login', component: Login },
{ path: 'register', component: RegisterComponent },
{ path: 'forgot-password', component: ForgotPasswordComponent },
{ path: 'reset-password', component: ResetPasswordComponent },
  {
  path: 'admin',
  component: AdminComponent,
  canActivate: [authGuard, roleGuard],
  data: { role: 'Admin' }
},
{
  path: 'trainer',
  component: TrainerComponent,
  canActivate: [authGuard, roleGuard],
  data: { role: 'Trainer' }
},
{
  path: 'student',
  component: StudentComponent,
  canActivate: [authGuard, roleGuard],
  data: { role: 'Student' }
},

  { path: '', redirectTo: 'login', pathMatch: 'full' }
];
