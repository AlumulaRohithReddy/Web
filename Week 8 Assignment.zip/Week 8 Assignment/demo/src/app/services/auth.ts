import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({ providedIn: 'root' })
export class AuthService {

  constructor(private http: HttpClient) {}
  private API = 'https://localhost:7242/api';
  login(data:any){
    return this.http.post(`${this.API}/Auth/login`, data);
  }

save(token: string) {
    console.log('Saving token:', token);
    localStorage.setItem('token', token);
  }
   getToken() {
  return localStorage.getItem('token');
}

  getRole() {
  const payload = this.getPayload();
  return payload
    ? payload['http://schemas.microsoft.com/ws/2008/06/identity/claims/role']
    : null;
}

  logout() {
  localStorage.removeItem('token');
}

 
isLoggedIn() {
  return !!localStorage.getItem('token');
}

getPayload() {
  const token = this.getToken();

  if (!token) return null;

  try {
    const cleanToken = token.trim();

    const parts = cleanToken.split('.');

 

    if (parts.length !== 3) {
      console.error('Invalid JWT format:', cleanToken);
      return null;
    }

    return JSON.parse(atob(parts[1]));
  } catch (error) {
    console.error('Decode error:', error);
    return null;
  }
}

verifyUser(data: any) {
  return this.http.post(`${this.API}/auth/verify-user`, data);
}

register(data: any) {
  return this.http.post<any>(`${this.API}/auth/register`, data);
}

forgotPassword(data: any) {
  return this.http.post(`${this.API}/auth/forgot-password`, data);
}

resetPassword(data: any) {
  return this.http.post(`${this.API}/auth/reset-password`, data);
}

isTokenExpired() {
  const payload = this.getPayload();
  if (!payload) return true;

  return Date.now() > payload.exp * 1000;
}
}