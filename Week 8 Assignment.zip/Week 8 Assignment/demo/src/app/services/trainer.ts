import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

export interface User {
  id: number;
  name: string;
  username: string;
  role: string;
}

@Injectable({
  providedIn: 'root'
})
export class TrainerService {

  private API = 'https://localhost:7242/api/Users';

  constructor(private http: HttpClient) {}

  // GET all students (filter by role)
  getStudents(): Observable<User[]> {
    const params = new HttpParams().set('role', 'Student');
    return this.http.get<User[]>(this.API, { params });
  }

  // UPDATE student (user)
  updateStudent(user: User) {
    return this.http.put(`${this.API}/${user.id}`, user);
  }

  // DELETE student
  deleteStudent(id: number) {
    return this.http.delete(`${this.API}/${id}`);
  }
}