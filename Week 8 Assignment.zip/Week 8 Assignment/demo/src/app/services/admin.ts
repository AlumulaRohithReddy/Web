import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  private apiUrl = 'https://localhost:7242/api/admin';

  constructor(private http: HttpClient) {}

  // Get all users
  getUsers() {
    return this.http.get(`${this.apiUrl}/users`);
  }

  // Delete user
  deleteUser(id: number) {
    return this.http.delete(`${this.apiUrl}/user/${id}`);
  }
}