import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

export interface StudyMaterial {
  id: number;
  title: string;
  description: string;
  fileUrl: string;
  createdBy: number;
}

@Injectable({
  providedIn: 'root'
})
export class MaterialService {

  private API = 'https://localhost:7242/api/Trainer';

  constructor(private http: HttpClient) {}

  // =============================
  // 🔹 GET ALL MATERIALS (Student)
  // =============================
  getMaterials(): Observable<StudyMaterial[]> {
    return this.http.get<StudyMaterial[]>("https://localhost:7242/api/Material");
  }

  // =============================
  // 🔹 GET TRAINER MATERIALS
  // =============================
  getMyMaterials(): Observable<StudyMaterial[]> {
    return this.http.get<StudyMaterial[]>(`${this.API}/my`);
  }

  // =============================
  // 🔹 GET MATERIAL BY ID
  // =============================
  getMaterialById(id: number): Observable<StudyMaterial> {
    return this.http.get<StudyMaterial>(`${this.API}/${id}`);
  }

  // =============================
  // 🔹 ADD MATERIAL (Trainer)
  // =============================
  addMaterial(material: {
    title: string;
    description: string;
    fileUrl: string;
  }) {
   
    return this.http.post(this.API, material);
  }

  // =============================
  // 🔹 UPDATE MATERIAL (Trainer)
  // =============================
  updateMaterial(material: StudyMaterial) {
    return this.http.put(`${this.API}/${material.id}`, material);
  }

  // =============================
  // 🔹 DELETE MATERIAL (Trainer)
  // =============================
  deleteMaterial(id: number) {
    return this.http.delete(`${this.API}/${id}`);
  }
}