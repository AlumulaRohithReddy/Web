﻿using Domain.Entities;
using Infrastructure.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace InterfaceAdapters.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Roles = "Trainer")]
    public class TrainerController : ControllerBase
    {
        private readonly AppDbContext _context;

        public TrainerController(AppDbContext context)
        {
            _context = context;
        }

        // Add Study Material
        //[HttpPost("materials")]
        //public async Task<IActionResult> AddMaterial(StudyMaterial material)
        //{
        //    _context.StudyMaterials.Add(material);
        //    await _context.SaveChangesAsync();

        //    return Ok(material);
        //}
        [Authorize(Roles = "Trainer")]
        [HttpPost]

[Authorize(Roles = "Trainer")]
    [HttpPost]
    public async Task<IActionResult> AddMaterial(StudyMaterial model)
    {
        // Get logged-in user ID from JWT
        var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);
            var material = new StudyMaterial();
            material.Title = model.Title;   
            material.Description = model.Description;
                material.FileUrl = model.FileUrl;
            material.CreatedBy = userId;
        _context.StudyMaterials.Add(material);
        await _context.SaveChangesAsync();

        return Ok(model);
    }
    [Authorize(Roles = "Trainer")]
        [HttpGet("my")]
        public async Task<IActionResult> GetMyMaterials()
        {
            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);

            var data = await _context.StudyMaterials
                .Where(x => x.CreatedBy == userId)
                .ToListAsync();

            return Ok(data);
        }
        // Get All Students
        //[HttpGet("students")]
        //public async Task<IActionResult> GetStudents()
        //{
        //    var students = await _context.Users
        //        .Where(u => u.Role == "Student")
        //        .ToListAsync();

        //    return Ok(students);
        //}

        // Update Student
        [HttpPut("student/{id}")]
        public async Task<IActionResult> UpdateStudent(int id, User updatedUser)
        {
            var user = await _context.Users.FindAsync(id);

            if (user == null)
                return NotFound();

            user.Name = updatedUser.Name;
         

            await _context.SaveChangesAsync();

            return Ok(user);
        }
    }
}