﻿using Infrastructure.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;


namespace Backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Roles = "Student")]
    public class StudentController : ControllerBase
    {
        private readonly AppDbContext _context;

        public StudentController(AppDbContext context)
        {
            _context = context;
        }

        // =============================
        // 🔹 GET CURRENT STUDENT PROFILE
        // =============================
        [HttpGet("me")]
        public async Task<IActionResult> GetProfile()
        {
            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);

            var user = await _context.Users
                .Where(u => u.Id == userId)
                .Select(u => new
                {
                    u.Id,
                    u.Name,
                    u.Username,
                    u.Role
                })
                .FirstOrDefaultAsync();

            if (user == null)
                return NotFound("User not found");

            return Ok(user);
        }

        // =============================
        // 🔹 GET ALL STUDY MATERIALS
        // =============================
        [HttpGet("materials")]
        public async Task<IActionResult> GetMaterials()
        {
            var materials = await _context.StudyMaterials
                .Select(m => new
                {
                    m.Id,
                    m.Title,
                    m.Description,
                    m.FileUrl,
                    m.CreatedBy
                })
                .ToListAsync();

            return Ok(materials);
        }

        // =============================
        // 🔹 GET SINGLE MATERIAL
        // =============================
        [HttpGet("materials/{id}")]
        public async Task<IActionResult> GetMaterial(int id)
        {
            var material = await _context.StudyMaterials.FindAsync(id);

            if (material == null)
                return NotFound("Material not found");

            return Ok(material);
        }

      
        // =============================
        // 🔹 DOWNLOAD MATERIAL
        // =============================
        [HttpGet("download/{id}")]
        public async Task<IActionResult> DownloadMaterial(int id)
        {
            var material = await _context.StudyMaterials.FindAsync(id);

            if (material == null)
                return NotFound("Material not found");

            // If fileUrl is external (like Google Drive, S3)
            return Redirect(material.FileUrl);
        }
    }
}