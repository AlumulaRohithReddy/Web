﻿using Domain.Entities;
using Infrastructure.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;


[Route("api/[controller]")]
[ApiController]
public class MaterialController : ControllerBase
{
    private readonly AppDbContext _context;

    public MaterialController(AppDbContext context)
    {
        _context = context;
    }

    // =============================
    // GET ALL MATERIALS (Student)
    // =============================
    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        return Ok(await _context.StudyMaterials.ToListAsync());
    }

    // =============================
    // GET TRAINER MATERIALS
    // =============================
    [Authorize(Roles = "Trainer")]
    [HttpGet("my")]
    public async Task<IActionResult> GetMy()
    {
        var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);

        var materials = await _context.StudyMaterials
            .Where(m => m.CreatedBy == userId)
            .ToListAsync();

        return Ok(materials);
    }

    // =============================
    // ADD MATERIAL
    // =============================
    [Authorize(Roles = "Trainer")]
    [HttpPost]
    public async Task<IActionResult> Add(StudyMaterial model)
    {
        var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);

        model.CreatedBy = userId;

        _context.StudyMaterials.Add(model);
        await _context.SaveChangesAsync();

        return Ok(model);
    }

    // =============================
    // DELETE MATERIAL
    // =============================
    [Authorize(Roles = "Trainer")]
    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        var material = await _context.StudyMaterials.FindAsync(id);

        if (material == null)
            return NotFound();

        _context.StudyMaterials.Remove(material);
        await _context.SaveChangesAsync();

        return Ok();
    }
}