﻿namespace Application.DTOs;

public class RegisterDto
{       public string Name { get; set; }
    public string Username { get; set; }
        public string Password { get; set; }
        public string Role { get; set; }   // Admin / Trainer / Student
    }
