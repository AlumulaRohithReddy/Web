﻿using System.Text.Json;

namespace Application.Services
{
    public class CaptchaService
    {
        private readonly HttpClient _httpClient;

        // 🔑 Replace with your SECRET KEY
        private readonly string _secret = "6LeBeHUsAAAAADmoEW8lP2OYmZEOW5miPstAYf-z";

        public CaptchaService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }


        public async Task<bool> VerifyToken(string token)
        {
            if (string.IsNullOrEmpty(token))
                return false;

            var response = await _httpClient.PostAsync(
                $"https://www.google.com/recaptcha/api/siteverify?secret={_secret}&response={token}",
                null
            );

            var json = await response.Content.ReadAsStringAsync();

            Console.WriteLine("CAPTCHA RESPONSE: " + json);

            var result = JsonSerializer.Deserialize<GoogleCaptchaResponse>(
                json,
                new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                }
            );

            Console.WriteLine("Captcha Success Value: " + result?.Success);

            return result != null && result.Success;
        }
    }

    public class GoogleCaptchaResponse
    {
        public bool Success { get; set; }
        public string[] ErrorCodes { get; set; }
    }
}