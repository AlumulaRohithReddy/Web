﻿using Application.DTOs;
using Application.Interfaces;
using Domain.Entities;
using Domain.Enums;
using System;


namespace Application.Services;

public class AuthService
{
    private readonly IUserRepository _repo;
    private readonly IJwtService _jwt;
    private readonly CaptchaService _captcha;

    public AuthService(IUserRepository repo, IJwtService jwt, CaptchaService captcha)
    {
        _repo = repo;
        _jwt = jwt;
        _captcha = captcha;
    }

    // CAPTCHA simulation
    private bool ValidateCaptcha(string captcha)
    {
        return captcha == "1234"; // dummy check
    }

    public async Task<string> Register(RegisterDto dto)
    {
        var user = new User
        {
            Name = dto.Name,
            Username = dto.Username,
            PasswordHash = BCrypt.Net.BCrypt.HashPassword(dto.Password),
            Role = Enum.Parse<UserRole>(dto.Role)
        };

        await _repo.AddAsync(user);

        return _jwt.GenerateToken(user);
    }

    public async Task<string> Login(LoginDto dto)
    {
        Console.WriteLine("Captcha Token: " + dto.Captcha);

        var isCaptchaValid = await _captcha.VerifyToken(dto.Captcha);

        Console.WriteLine("Captcha Valid: " + isCaptchaValid);

        if (!isCaptchaValid)
            throw new Exception("Captcha validation failed");

        var user = await _repo.GetByUsernameAsync(dto.Username);

        if (user == null || !BCrypt.Net.BCrypt.Verify(dto.Password, user.PasswordHash))
            throw new Exception("Invalid credentials");

        return _jwt.GenerateToken(user);
    }

    public async Task ForgotPassword(string username)
    {
        var user = await _repo.GetByUsernameAsync(username);
        if (user == null) throw new Exception("User not found");

        user.ResetToken = Guid.NewGuid().ToString();
        user.ResetTokenExpiry = DateTime.Now.AddMinutes(15);

        await _repo.UpdateAsync(user);

        // Send via email (for now print)
        Console.WriteLine($"Reset Token: {user.ResetToken}");
    }

    
}