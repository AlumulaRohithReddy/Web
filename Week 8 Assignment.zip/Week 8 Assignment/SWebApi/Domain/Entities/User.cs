﻿using Domain.Enums;

namespace Domain.Entities;

public class User
{
    public int Id { get; set; } 
    public string Name { get; set; }
    public string Username { get; set; } = string.Empty;
    public string PasswordHash { get; set; } = string.Empty;
    public UserRole Role { get; set; }
    public string? ResetToken { get; set; }
    public DateTime? ResetTokenExpiry { get; set; }
}