﻿namespace Domain.Enums;


public enum UserRole
{
    Admin = 0,
    Trainer = 1,
    Student = 2
}