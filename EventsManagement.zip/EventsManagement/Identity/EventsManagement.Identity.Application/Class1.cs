﻿namespace EventsManagement.Identity.Application;

public class Class1
{

}
