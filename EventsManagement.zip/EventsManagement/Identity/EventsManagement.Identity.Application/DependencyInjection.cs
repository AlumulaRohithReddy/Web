using Microsoft.Extensions.DependencyInjection;
using EventsManagement.Identity.Application.Services;

namespace EventsManagement.Identity.Application
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddApplication(this IServiceCollection services)
        {
            services.AddScoped<IAuthService, AuthService>();
            return services;
        }
    }
}
