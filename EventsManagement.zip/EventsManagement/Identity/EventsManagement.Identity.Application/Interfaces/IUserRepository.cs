using EventsManagement.Identity.Domain;

namespace EventsManagement.Identity.Application.Interfaces
{
    using EventsManagement.Identity.Domain.Entities;

    public interface IUserRepository
    {
        Task<User?> GetByIdAsync(string id);
        Task<User?> GetByUsernameAsync(string username);
        Task<User?> GetByEmailAsync(string email);
        Task CreateAsync(User user);
    }
}
