using EventsManagement.Identity.Domain;
using EventsManagement.Identity.Domain.Entities;

namespace EventsManagement.Identity.Application.Interfaces
{
    public interface ITokenService
    {
        string GenerateToken(User user);
    }
}
