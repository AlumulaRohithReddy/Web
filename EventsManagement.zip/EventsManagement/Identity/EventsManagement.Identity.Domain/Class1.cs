﻿namespace EventsManagement.Identity.Domain;

public class Class1
{

}
