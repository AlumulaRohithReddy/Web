using EventsManagement.Identity.Application.Interfaces;
using EventsManagement.Identity.Application.DTOs.Auth;
using EventsManagement.Identity.Application.Services;
using EventsManagement.Identity.Domain.Entities;
using Microsoft.AspNetCore.Mvc;

namespace EventsManagement.Identity.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly IUserRepository _userRepository;
        private readonly ITokenService _tokenService;
        private readonly IAuthService _authService;

        public AuthController(IUserRepository userRepository, ITokenService tokenService, IAuthService authService)
        {
            _userRepository = userRepository;
            _tokenService = tokenService;
            _authService = authService;
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register(RegisterDto registerDto)
        {
            if (await _userRepository.GetByUsernameAsync(registerDto.Username) != null)
                return BadRequest("Username already exists");

            if (await _userRepository.GetByEmailAsync(registerDto.Email) != null)
                return BadRequest("Email already exists");

            var user = new User
            {
                Username = registerDto.Username,
                Email = registerDto.Email,
                PasswordHash = _authService.HashPassword(registerDto.Password),
                Role = registerDto.Role
            };

            await _userRepository.CreateAsync(user);

            return Ok(new AuthResponseDto
            {
                Token = _tokenService.GenerateToken(user),
                Username = user.Username
            });
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login(LoginDto loginDto)
        {
            var user = await _userRepository.GetByUsernameAsync(loginDto.Username);

            if (user == null || !_authService.VerifyPassword(loginDto.Password, user.PasswordHash))
                return Unauthorized("Invalid username or password");

            return Ok(new AuthResponseDto
            {
                Token = _tokenService.GenerateToken(user),
                Username = user.Username
            });
        }

    }
}
