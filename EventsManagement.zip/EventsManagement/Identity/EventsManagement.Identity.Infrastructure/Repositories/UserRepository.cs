using EventsManagement.Identity.Application.Interfaces;
using EventsManagement.Identity.Domain.Entities;
using MongoDB.Driver;
using Microsoft.Extensions.Configuration;

namespace EventsManagement.Identity.Infrastructure.Repositories
{
    using EventsManagement.Identity.Application;
    using EventsManagement.Identity.Domain;
    public class UserRepository : IUserRepository
    {
        private readonly IMongoCollection<User> _users;

        public UserRepository(IConfiguration config)
        {
            var client = new MongoClient(config.GetConnectionString("MongoDb"));
            var database = client.GetDatabase("IdentityDb");
            _users = database.GetCollection<User>("Users");
        }

        public async Task<User?> GetByIdAsync(string id) =>
            await _users.Find(u => u.Id == id).FirstOrDefaultAsync();

        public async Task<User?> GetByUsernameAsync(string username) =>
            await _users.Find(u => u.Username == username).FirstOrDefaultAsync();

        public async Task<User?> GetByEmailAsync(string email) =>
            await _users.Find(u => u.Email == email).FirstOrDefaultAsync();

        public async Task CreateAsync(User user) =>
            await _users.InsertOneAsync(user);
    }
}
