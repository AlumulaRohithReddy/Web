using Microsoft.Extensions.DependencyInjection;
using EventsManagement.Identity.Application.Interfaces;
using EventsManagement.Identity.Infrastructure.Repositories;
using EventsManagement.Identity.Infrastructure.Authentication;

namespace EventsManagement.Identity.Infrastructure
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddInfrastructure(this IServiceCollection services)
        {
            services.AddScoped<IUserRepository, UserRepository>();
            services.AddScoped<ITokenService, TokenService>();
            return services;
        }
    }
}
