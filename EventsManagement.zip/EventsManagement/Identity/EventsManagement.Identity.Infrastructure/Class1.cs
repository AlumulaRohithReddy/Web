﻿namespace EventsManagement.Identity.Infrastructure;

public class Class1
{

}
