using System.ComponentModel.DataAnnotations;

namespace EventsManagement.EventManager.Domain.Entities
{
    public class Guest
    {
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string FullName { get; set; } = string.Empty;

        [EmailAddress]
        public string Email { get; set; } = string.Empty;

        public bool IsRSVPed { get; set; }
        public string Category { get; set; } = "General";
        public int GroupSize { get; set; } = 1;
    }
}
