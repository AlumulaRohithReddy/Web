using System.ComponentModel.DataAnnotations;

namespace EventsManagement.EventManager.Domain.Entities
{
    public class Vendor
    {
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string Name { get; set; } = string.Empty;

        [Required]
        public string Category { get; set; } = string.Empty;

        public decimal Budget { get; set; }
        public decimal PaidAmount { get; set; }
        public decimal PendingAmount => Budget - PaidAmount;

        public string ContactEmail { get; set; } = string.Empty;
        public string Status { get; set; } = "Active";
    }
}
