﻿namespace EventsManagement.EventManager.Domain;

public class Class1
{

}
