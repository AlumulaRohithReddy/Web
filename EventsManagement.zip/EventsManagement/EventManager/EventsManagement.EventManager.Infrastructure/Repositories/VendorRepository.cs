using EventsManagement.EventManager.Application.Interfaces;
using EventsManagement.EventManager.Domain.Entities;
using EventsManagement.EventManager.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace EventsManagement.EventManager.Infrastructure.Repositories
{
    public class VendorRepository : IVendorRepository
    {
        private readonly EventDbContext _context;

        public VendorRepository(EventDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Vendor>> GetAllAsync() => await _context.Vendors.ToListAsync();
        public async Task<Vendor?> GetByIdAsync(int id) => await _context.Vendors.FindAsync(id);
        public async Task CreateAsync(Vendor vendor)
        {
            _context.Vendors.Add(vendor);
            await _context.SaveChangesAsync();
        }
        public async Task UpdateAsync(Vendor vendor)
        {
            _context.Vendors.Update(vendor);
            await _context.SaveChangesAsync();
        }
        public async Task DeleteAsync(int id)
        {
            var vendor = await _context.Vendors.FindAsync(id);
            if (vendor != null)
            {
                _context.Vendors.Remove(vendor);
                await _context.SaveChangesAsync();
            }
        }
    }
}
