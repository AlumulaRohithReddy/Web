using EventsManagement.EventManager.Application.Interfaces;
using EventsManagement.EventManager.Domain;
using EventsManagement.EventManager.Domain.Entities;
using EventsManagement.EventManager.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace EventsManagement.EventManager.Infrastructure.Repositories
{
    public class GuestRepository : IGuestRepository
    {
        private readonly EventDbContext _context;

        public GuestRepository(EventDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Guest>> GetAllAsync() => await _context.Guests.ToListAsync();
        public async Task<Guest?> GetByIdAsync(int id) => await _context.Guests.FindAsync(id);
        public async Task CreateAsync(Guest guest)
        {
            _context.Guests.Add(guest);
            await _context.SaveChangesAsync();
        }
        public async Task UpdateAsync(Guest guest)
        {
            _context.Guests.Update(guest);
            await _context.SaveChangesAsync();
        }
        public async Task DeleteAsync(int id)
        {
            var guest = await _context.Guests.FindAsync(id);
            if (guest != null)
            {
                _context.Guests.Remove(guest);
                await _context.SaveChangesAsync();
            }
        }
    }
}
