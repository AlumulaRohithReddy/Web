using EventsManagement.EventManager.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace EventsManagement.EventManager.Infrastructure.Data
{
    public class EventDbContext : DbContext
    {
        public EventDbContext(DbContextOptions<EventDbContext> options) : base(options) { }

        public DbSet<Vendor> Vendors { get; set; }
        public DbSet<Guest> Guests { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Vendor>().Property(v => v.Budget).HasPrecision(18, 2);
            modelBuilder.Entity<Vendor>().Property(v => v.PaidAmount).HasPrecision(18, 2);
        }
    }
}
