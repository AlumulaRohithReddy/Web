﻿namespace EventsManagement.EventManager.Infrastructure;

public class Class1
{

}
