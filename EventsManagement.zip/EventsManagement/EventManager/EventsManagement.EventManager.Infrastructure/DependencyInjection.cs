using Microsoft.Extensions.DependencyInjection;
using EventsManagement.EventManager.Application.Interfaces;
using EventsManagement.EventManager.Infrastructure.Repositories;
using EventsManagement.EventManager.Infrastructure.Data;

namespace EventsManagement.EventManager.Infrastructure
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddInfrastructure(this IServiceCollection services)
        {
            services.AddScoped<IVendorRepository, VendorRepository>();
            services.AddScoped<IGuestRepository, GuestRepository>();
            return services;
        }
    }
}
