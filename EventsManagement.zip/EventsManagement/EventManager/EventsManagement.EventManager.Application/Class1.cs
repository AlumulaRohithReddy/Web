﻿namespace EventsManagement.EventManager.Application;

public class Class1
{

}
