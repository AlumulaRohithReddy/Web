using Microsoft.Extensions.DependencyInjection;
using EventsManagement.EventManager.Application.Interfaces;

namespace EventsManagement.EventManager.Application
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddApplication(this IServiceCollection services)
        {
            // Register application services here
            return services;
        }
    }
}
