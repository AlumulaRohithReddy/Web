using EventsManagement.EventManager.Domain;
using EventsManagement.EventManager.Domain.Entities;

namespace EventsManagement.EventManager.Application.Interfaces
{
    public interface IVendorRepository
    {
        Task<IEnumerable<Vendor>> GetAllAsync();
        Task<Vendor?> GetByIdAsync(int id);
        Task CreateAsync(Vendor vendor);
        Task UpdateAsync(Vendor vendor);
        Task DeleteAsync(int id);
    }
}
