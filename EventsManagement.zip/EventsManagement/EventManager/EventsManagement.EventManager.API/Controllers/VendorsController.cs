using EventsManagement.EventManager.Application.Interfaces;
using EventsManagement.EventManager.Domain.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EventsManagement.EventManager.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class VendorsController : ControllerBase
    {
        private readonly IVendorRepository _repository;

        public VendorsController(IVendorRepository repository)
        {
            _repository = repository;
        }

        // GET: api/Vendors  (Any authenticated user)
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Vendor>>> GetVendors()
        {
            var vendors = await _repository.GetAllAsync();
            return Ok(vendors);
        }

        // GET: api/Vendors/{id}  (Any authenticated user)
        [HttpGet("{id}")]
        public async Task<ActionResult<Vendor>> GetVendor(int id)
        {
            var vendor = await _repository.GetByIdAsync(id);
            if (vendor == null) return NotFound();
            return Ok(vendor);
        }

        // POST: api/Vendors  (Any authenticated user)
        [HttpPost]
        public async Task<ActionResult<Vendor>> CreateVendor(Vendor vendor)
        {
            await _repository.CreateAsync(vendor);
            return CreatedAtAction(nameof(GetVendor), new { id = vendor.Id }, vendor);
        }

        // PUT: api/Vendors/{id}  (Admin only)
        [HttpPut("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> UpdateVendor(int id, Vendor vendor)
        {
            if (id != vendor.Id) return BadRequest();
            await _repository.UpdateAsync(vendor);
            return NoContent();
        }

        // DELETE: api/Vendors/{id}  (Admin only)
        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteVendor(int id)
        {
            await _repository.DeleteAsync(id);
            return NoContent();
        }
    }
}
