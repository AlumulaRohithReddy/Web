using EventsManagement.EventManager.Application.Interfaces;
using EventsManagement.EventManager.Domain.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EventsManagement.EventManager.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class GuestsController : ControllerBase
    {
        private readonly IGuestRepository _repository;

        public GuestsController(IGuestRepository repository)
        {
            _repository = repository;
        }

        // GET: api/Guests  (Any authenticated user)
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Guest>>> GetGuests()
        {
            var guests = await _repository.GetAllAsync();
            return Ok(guests);
        }

        // GET: api/Guests/{id}  (Any authenticated user)
        [HttpGet("{id}")]
        public async Task<ActionResult<Guest>> GetGuest(int id)
        {
            var guest = await _repository.GetByIdAsync(id);
            if (guest == null) return NotFound();
            return Ok(guest);
        }

        // POST: api/Guests  (Any authenticated user)
        [HttpPost]
        public async Task<ActionResult<Guest>> CreateGuest(Guest guest)
        {
            await _repository.CreateAsync(guest);
            return CreatedAtAction(nameof(GetGuest), new { id = guest.Id }, guest);
        }

        // PUT: api/Guests/{id}  (Admin only)
        [HttpPut("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> UpdateGuest(int id, Guest guest)
        {
            if (id != guest.Id) return BadRequest();
            await _repository.UpdateAsync(guest);
            return NoContent();
        }

        // DELETE: api/Guests/{id}  (Admin only)
        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteGuest(int id)
        {
            await _repository.DeleteAsync(id);
            return NoContent();
        }
    }
}
